package com.jwt.security.model;

public enum Role {
 USER,
 ADMIN
}
