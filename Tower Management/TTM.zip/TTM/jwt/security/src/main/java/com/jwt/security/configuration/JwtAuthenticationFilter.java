package com.jwt.security.configuration;

import java.io.IOException;

import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;


@Component  //By default, @Component beans are singleton-scoped, meaning that the same instance of the bean is shared across the application. However, you can change the scope if needed using the @Scope annotation.
//Dependency Injection: Once registered as a bean, the class can be injected into other Spring-managed components using annotations like @Autowired.
// Automatic Detection: Classes annotated with @Component are automatically detected and registered as beans during classpath scanning.
//Automatic Detection: Classes annotated with @Component are automatically detected and registered as beans during classpath scanning.
@RequiredArgsConstructor // creates constructor for final variables declared 
public class JwtAuthenticationFilter extends  OncePerRequestFilter{
    

   private final JwtService jwtService;
   private final UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(
       @NonNull HttpServletRequest request, 
       @NonNull HttpServletResponse response, 
       @NonNull FilterChain filterChain
        ) throws ServletException, IOException {
        final String authHeader = request.getHeader("Authorization");
        final String jwt;
        final String userEmail;
        if(authHeader == null || !authHeader.startsWith("Bearer")){
            filterChain.doFilter(request, response);
            return;
        }
        jwt = authHeader.substring(7);
        userEmail = jwtService.extractUsername(jwt);
        if(userEmail != null && SecurityContextHolder.getContext().getAuthentication() == null){
            UserDetails userDetails = this.userDetailsService.loadUserByUsername(userEmail);
            if(jwtService.isTokenValid(jwt, userDetails)){
                UsernamePasswordAuthenticationToken authToken = 
                new UsernamePasswordAuthenticationToken(
                    userDetails,
                    null,
                    userDetails.getAuthorities());

                authToken.setDetails(
                    new WebAuthenticationDetailsSource()
                    .buildDetails(request)
                    );

                SecurityContextHolder
                .getContext()
                .setAuthentication(authToken);
            }
        }
        filterChain.doFilter(request, response);
    }
    
}
